#pragma once

#include"ChangePassword.h"
#include"LoginPage.h"
#include"EmployeePage.h"

#include<iostream>
#include<fstream>
#include<stdlib.h>
#include<string>
#include<cstring>
#include<io.h>
#include<filesystem>
#pragma warning(push)
#pragma warning(disable: 4101)
#pragma warning(disable: 4102)

namespace ISEIncrement3 {

	using namespace std;
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::IO;

	/// <summary>
	/// Summary for LoginPage
	/// </summary>
	public ref class LoginPage : public System::Windows::Forms::Form
	{
	public:
		LoginPage(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~LoginPage()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  Loginbutton;
	protected: 
	private: System::Windows::Forms::TextBox^  textBoxPassword;
	private: System::Windows::Forms::Label^  PasswordLabel;
	private: System::Windows::Forms::Label^  UserIDLabel;
	private: System::Windows::Forms::TextBox^  textBoxUserID;
	private: System::Windows::Forms::PictureBox^  LESCOpicture;
	private: System::Windows::Forms::PictureBox^  exitbutton;
	private: System::Windows::Forms::Label^  ChangepasswordLabel;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(LoginPage::typeid));
			this->Loginbutton = (gcnew System::Windows::Forms::Button());
			this->textBoxPassword = (gcnew System::Windows::Forms::TextBox());
			this->PasswordLabel = (gcnew System::Windows::Forms::Label());
			this->UserIDLabel = (gcnew System::Windows::Forms::Label());
			this->textBoxUserID = (gcnew System::Windows::Forms::TextBox());
			this->LESCOpicture = (gcnew System::Windows::Forms::PictureBox());
			this->exitbutton = (gcnew System::Windows::Forms::PictureBox());
			this->ChangepasswordLabel = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->LESCOpicture))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->exitbutton))->BeginInit();
			this->SuspendLayout();
			// 
			// Loginbutton
			// 
			this->Loginbutton->BackColor = System::Drawing::Color::LightGray;
			this->Loginbutton->BackgroundImageLayout = System::Windows::Forms::ImageLayout::None;
			this->Loginbutton->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->Loginbutton->Font = (gcnew System::Drawing::Font(L"Georgia", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Loginbutton->Location = System::Drawing::Point(269, 256);
			this->Loginbutton->Name = L"Loginbutton";
			this->Loginbutton->Size = System::Drawing::Size(86, 33);
			this->Loginbutton->TabIndex = 24;
			this->Loginbutton->Text = L"Login";
			this->Loginbutton->UseVisualStyleBackColor = false;
			this->Loginbutton->Click += gcnew System::EventHandler(this, &LoginPage::Loginbutton_Click);
			// 
			// textBoxPassword
			// 
			this->textBoxPassword->BackColor = System::Drawing::Color::Lavender;
			this->textBoxPassword->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->textBoxPassword->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14.25F, System::Drawing::FontStyle::Regular, 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->textBoxPassword->Location = System::Drawing::Point(298, 179);
			this->textBoxPassword->Name = L"textBoxPassword";
			this->textBoxPassword->Size = System::Drawing::Size(169, 29);
			this->textBoxPassword->TabIndex = 23;
			// 
			// PasswordLabel
			// 
			this->PasswordLabel->AutoSize = true;
			this->PasswordLabel->BackColor = System::Drawing::Color::Silver;
			this->PasswordLabel->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->PasswordLabel->Font = (gcnew System::Drawing::Font(L"Georgia", 15.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->PasswordLabel->Location = System::Drawing::Point(158, 182);
			this->PasswordLabel->Name = L"PasswordLabel";
			this->PasswordLabel->Size = System::Drawing::Size(115, 27);
			this->PasswordLabel->TabIndex = 22;
			this->PasswordLabel->Text = L"Password: ";
			// 
			// UserIDLabel
			// 
			this->UserIDLabel->AutoSize = true;
			this->UserIDLabel->BackColor = System::Drawing::Color::Silver;
			this->UserIDLabel->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->UserIDLabel->Font = (gcnew System::Drawing::Font(L"Georgia", 15.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->UserIDLabel->Location = System::Drawing::Point(159, 146);
			this->UserIDLabel->Name = L"UserIDLabel";
			this->UserIDLabel->Size = System::Drawing::Size(114, 27);
			this->UserIDLabel->TabIndex = 21;
			this->UserIDLabel->Text = L"User ID:    ";
			// 
			// textBoxUserID
			// 
			this->textBoxUserID->BackColor = System::Drawing::Color::Lavender;
			this->textBoxUserID->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->textBoxUserID->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBoxUserID->Location = System::Drawing::Point(298, 144);
			this->textBoxUserID->Name = L"textBoxUserID";
			this->textBoxUserID->Size = System::Drawing::Size(169, 29);
			this->textBoxUserID->TabIndex = 20;
			// 
			// LESCOpicture
			// 
			this->LESCOpicture->BackColor = System::Drawing::Color::White;
			this->LESCOpicture->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->LESCOpicture->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"LESCOpicture.Image")));
			this->LESCOpicture->Location = System::Drawing::Point(12, 12);
			this->LESCOpicture->Name = L"LESCOpicture";
			this->LESCOpicture->Size = System::Drawing::Size(643, 76);
			this->LESCOpicture->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->LESCOpicture->TabIndex = 19;
			this->LESCOpicture->TabStop = false;
			// 
			// exitbutton
			// 
			this->exitbutton->BackColor = System::Drawing::Color::White;
			this->exitbutton->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"exitbutton.Image")));
			this->exitbutton->Location = System::Drawing::Point(613, 23);
			this->exitbutton->Name = L"exitbutton";
			this->exitbutton->Size = System::Drawing::Size(31, 28);
			this->exitbutton->SizeMode = System::Windows::Forms::PictureBoxSizeMode::StretchImage;
			this->exitbutton->TabIndex = 25;
			this->exitbutton->TabStop = false;
			this->exitbutton->Click += gcnew System::EventHandler(this, &LoginPage::exitbutton_Click);
			// 
			// ChangepasswordLabel
			// 
			this->ChangepasswordLabel->AutoSize = true;
			this->ChangepasswordLabel->BackColor = System::Drawing::Color::Transparent;
			this->ChangepasswordLabel->Font = (gcnew System::Drawing::Font(L"Georgia", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->ChangepasswordLabel->ForeColor = System::Drawing::Color::Red;
			this->ChangepasswordLabel->Location = System::Drawing::Point(352, 211);
			this->ChangepasswordLabel->Name = L"ChangepasswordLabel";
			this->ChangepasswordLabel->Size = System::Drawing::Size(115, 16);
			this->ChangepasswordLabel->TabIndex = 26;
			this->ChangepasswordLabel->Text = L"Change Password";
			this->ChangepasswordLabel->Click += gcnew System::EventHandler(this, &LoginPage::ChangepasswordLabel_Click);
			// 
			// LoginPage
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"$this.BackgroundImage")));
			this->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->ClientSize = System::Drawing::Size(678, 319);
			this->Controls->Add(this->ChangepasswordLabel);
			this->Controls->Add(this->exitbutton);
			this->Controls->Add(this->Loginbutton);
			this->Controls->Add(this->textBoxPassword);
			this->Controls->Add(this->PasswordLabel);
			this->Controls->Add(this->UserIDLabel);
			this->Controls->Add(this->textBoxUserID);
			this->Controls->Add(this->LESCOpicture);
			this->Name = L"LoginPage";
			this->Text = L"Login";
			this->Load += gcnew System::EventHandler(this, &LoginPage::LoginPage_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->LESCOpicture))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->exitbutton))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void LoginPage_Load(System::Object^  sender, System::EventArgs^  e) {
			 }

	private: System::Void Loginbutton_Click(System::Object^  sender, System::EventArgs^  e) {
	std::ifstream Myfile;
	std::ifstream fin;
	std::ifstream input;
    char ch;
	std::string ID;
	std::string PW;
	std::string lgID;
	std::string lgpass;
	int srch, srch1, sampleuID, sampleID;
	bool idCheck,lgCheck,LoginWhile;
	std::string usernic;
	while(!0){
    	fin.open("EmployeesData.txt");
		/*cout << "Enter ID:";
        cin >> lgID;
        cout << "Enter Password:";
        cin >> lgpass;*/
		String^ lgIDw=textBoxUserID->Text;
		String^ lgpassw=textBoxPassword->Text;
		StreamWriter^ w=File::CreateText("wr.txt");
		w->Write(lgIDw);
		w->Write(' ');
		w->Write(lgpassw);
		w->Close();
		std::ifstream r;
		r.open("wr.txt",ios::in);
		//while(!r.eof())
		r>>lgID;
		r>>lgpass;
		r.close();
//		w->Close();
	//	r.open("wr.txt");
	//	r.close();
	//	std::cout<<lgID<<" "<<lgpass<<endl;
	if (fin.is_open()){
	while (!fin.eof()){
	fin>>ID>>PW;
	if (ID==lgID){
	idCheck=true;
	break;}}
	if (ID!=lgID){
	idCheck=false;
	if(MessageBox::Show("Sorry, NO record found for this ID.","Wrong Input",MessageBoxButtons::OKCancel,MessageBoxIcon::Error)==System::Windows::Forms::DialogResult::Cancel)
	Loginbutton->PerformClick();}
	else{
		if (lgID==ID && lgpass==PW){
        MessageBox::Show("Login successful!");
        cout << endl;
        lgCheck=true;
        EmployeePage obj;
		this->Hide();
		obj.ShowDialog();}
        else{
        lgCheck=false;
        if(MessageBox::Show("Login failed!\nWrong password.","Wrong Input",MessageBoxButtons::OKCancel,MessageBoxIcon::Error)==System::Windows::Forms::DialogResult::Cancel)
		Loginbutton->PerformClick();
        }}
	fin.close();}
	else
	if(MessageBox::Show("Could not open file.","Wrong Input",MessageBoxButtons::OKCancel,MessageBoxIcon::Error)==System::Windows::Forms::DialogResult::Cancel)
	Loginbutton->PerformClick();
     //   input.close();
	if (idCheck==true && lgCheck==true){
    LoginWhile=true;
	break;}}

			 }
private: System::Void ChangepasswordLabel_Click(System::Object^  sender, System::EventArgs^  e) {
			 ChangePassword obj;
			 obj.ShowDialog();
		 }
private: System::Void exitbutton_Click(System::Object^  sender, System::EventArgs^  e) {
			 Application::Exit();
		 }
};
}
#pragma warning(pop)
