#pragma once

namespace ISEIncrement3 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Tariff
	/// </summary>
	public ref class Tariff : public System::Windows::Forms::Form
	{
	public:
		Tariff(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Tariff()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::PictureBox^  pictureBox1;
	private: System::Windows::Forms::Label^  Tarifflabel;
	protected: 

	private: System::Windows::Forms::Button^  DisplayTariffFile;
	private: System::Windows::Forms::Button^  ViewUpdatebutton;
	private: System::Windows::Forms::Button^  UpdateTraiffbutton;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Tariff::typeid));
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->Tarifflabel = (gcnew System::Windows::Forms::Label());
			this->DisplayTariffFile = (gcnew System::Windows::Forms::Button());
			this->ViewUpdatebutton = (gcnew System::Windows::Forms::Button());
			this->UpdateTraiffbutton = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox1.BackgroundImage")));
			this->pictureBox1->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->pictureBox1->Location = System::Drawing::Point(-1, 0);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(37, 31);
			this->pictureBox1->TabIndex = 9;
			this->pictureBox1->TabStop = false;
			// 
			// Tarifflabel
			// 
			this->Tarifflabel->AutoSize = true;
			this->Tarifflabel->BackColor = System::Drawing::Color::Transparent;
			this->Tarifflabel->Font = (gcnew System::Drawing::Font(L"Georgia", 15.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Tarifflabel->Location = System::Drawing::Point(177, 55);
			this->Tarifflabel->Name = L"Tarifflabel";
			this->Tarifflabel->Size = System::Drawing::Size(183, 25);
			this->Tarifflabel->TabIndex = 8;
			this->Tarifflabel->Text = L"Tariff Information";
			this->Tarifflabel->Click += gcnew System::EventHandler(this, &Tariff::CNICexpirylabel_Click);
			// 
			// DisplayTariffFile
			// 
			this->DisplayTariffFile->BackColor = System::Drawing::Color::Transparent;
			this->DisplayTariffFile->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->DisplayTariffFile->Font = (gcnew System::Drawing::Font(L"Georgia", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->DisplayTariffFile->Location = System::Drawing::Point(154, 184);
			this->DisplayTariffFile->Name = L"DisplayTariffFile";
			this->DisplayTariffFile->Size = System::Drawing::Size(222, 35);
			this->DisplayTariffFile->TabIndex = 7;
			this->DisplayTariffFile->Text = L"Display Tariff File";
			this->DisplayTariffFile->UseVisualStyleBackColor = false;
			// 
			// ViewUpdatebutton
			// 
			this->ViewUpdatebutton->BackColor = System::Drawing::Color::Transparent;
			this->ViewUpdatebutton->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->ViewUpdatebutton->Font = (gcnew System::Drawing::Font(L"Georgia", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->ViewUpdatebutton->Location = System::Drawing::Point(154, 143);
			this->ViewUpdatebutton->Name = L"ViewUpdatebutton";
			this->ViewUpdatebutton->Size = System::Drawing::Size(222, 35);
			this->ViewUpdatebutton->TabIndex = 6;
			this->ViewUpdatebutton->Text = L"View Update";
			this->ViewUpdatebutton->UseVisualStyleBackColor = false;
			// 
			// UpdateTraiffbutton
			// 
			this->UpdateTraiffbutton->BackColor = System::Drawing::Color::Transparent;
			this->UpdateTraiffbutton->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->UpdateTraiffbutton->Font = (gcnew System::Drawing::Font(L"Georgia", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->UpdateTraiffbutton->Location = System::Drawing::Point(154, 102);
			this->UpdateTraiffbutton->Name = L"UpdateTraiffbutton";
			this->UpdateTraiffbutton->Size = System::Drawing::Size(222, 35);
			this->UpdateTraiffbutton->TabIndex = 5;
			this->UpdateTraiffbutton->Text = L"Update a tariff";
			this->UpdateTraiffbutton->UseVisualStyleBackColor = false;
			// 
			// Tariff
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"$this.BackgroundImage")));
			this->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->ClientSize = System::Drawing::Size(557, 285);
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->Tarifflabel);
			this->Controls->Add(this->DisplayTariffFile);
			this->Controls->Add(this->ViewUpdatebutton);
			this->Controls->Add(this->UpdateTraiffbutton);
			this->Name = L"Tariff";
			this->Text = L"Tariff";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void CNICexpirylabel_Click(System::Object^  sender, System::EventArgs^  e) {
			 }
};
}
