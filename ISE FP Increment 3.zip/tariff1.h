#pragma once

namespace ISEIncrement3 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for tariff
	/// </summary>
	public ref class tariff : public System::Windows::Forms::Form
	{
	public:
		tariff(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~tariff()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::PictureBox^  pictureBox1;
	protected: 
	private: System::Windows::Forms::Label^  Tarifflabel;
	private: System::Windows::Forms::Button^  UpdateExpirybutton;
	private: System::Windows::Forms::Button^  ViewClosebutton;
	private: System::Windows::Forms::Button^  ViewAllExpirybutton;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(tariff::typeid));
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->Tarifflabel = (gcnew System::Windows::Forms::Label());
			this->UpdateExpirybutton = (gcnew System::Windows::Forms::Button());
			this->ViewClosebutton = (gcnew System::Windows::Forms::Button());
			this->ViewAllExpirybutton = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox1.BackgroundImage")));
			this->pictureBox1->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->pictureBox1->Location = System::Drawing::Point(-1, -1);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(37, 31);
			this->pictureBox1->TabIndex = 9;
			this->pictureBox1->TabStop = false;
			// 
			// Tarifflabel
			// 
			this->Tarifflabel->AutoSize = true;
			this->Tarifflabel->BackColor = System::Drawing::Color::Transparent;
			this->Tarifflabel->Font = (gcnew System::Drawing::Font(L"Georgia", 15.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Tarifflabel->Location = System::Drawing::Point(152, 42);
			this->Tarifflabel->Name = L"Tarifflabel";
			this->Tarifflabel->Size = System::Drawing::Size(183, 25);
			this->Tarifflabel->TabIndex = 8;
			this->Tarifflabel->Text = L"Tariff Information";
			// 
			// UpdateExpirybutton
			// 
			this->UpdateExpirybutton->BackColor = System::Drawing::Color::Transparent;
			this->UpdateExpirybutton->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->UpdateExpirybutton->Font = (gcnew System::Drawing::Font(L"Georgia", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->UpdateExpirybutton->Location = System::Drawing::Point(132, 177);
			this->UpdateExpirybutton->Name = L"UpdateExpirybutton";
			this->UpdateExpirybutton->Size = System::Drawing::Size(222, 35);
			this->UpdateExpirybutton->TabIndex = 7;
			this->UpdateExpirybutton->Text = L"View Tariff File";
			this->UpdateExpirybutton->UseVisualStyleBackColor = false;
			// 
			// ViewClosebutton
			// 
			this->ViewClosebutton->BackColor = System::Drawing::Color::Transparent;
			this->ViewClosebutton->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->ViewClosebutton->Font = (gcnew System::Drawing::Font(L"Georgia", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->ViewClosebutton->Location = System::Drawing::Point(132, 136);
			this->ViewClosebutton->Name = L"ViewClosebutton";
			this->ViewClosebutton->Size = System::Drawing::Size(222, 35);
			this->ViewClosebutton->TabIndex = 6;
			this->ViewClosebutton->Text = L"View Update";
			this->ViewClosebutton->UseVisualStyleBackColor = false;
			// 
			// ViewAllExpirybutton
			// 
			this->ViewAllExpirybutton->BackColor = System::Drawing::Color::Transparent;
			this->ViewAllExpirybutton->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->ViewAllExpirybutton->Font = (gcnew System::Drawing::Font(L"Georgia", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->ViewAllExpirybutton->Location = System::Drawing::Point(132, 95);
			this->ViewAllExpirybutton->Name = L"ViewAllExpirybutton";
			this->ViewAllExpirybutton->Size = System::Drawing::Size(222, 35);
			this->ViewAllExpirybutton->TabIndex = 5;
			this->ViewAllExpirybutton->Text = L"Update info";
			this->ViewAllExpirybutton->UseVisualStyleBackColor = false;
			// 
			// tariff
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"$this.BackgroundImage")));
			this->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->ClientSize = System::Drawing::Size(521, 269);
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->Tarifflabel);
			this->Controls->Add(this->UpdateExpirybutton);
			this->Controls->Add(this->ViewClosebutton);
			this->Controls->Add(this->ViewAllExpirybutton);
			this->Name = L"tariff";
			this->Text = L"LESCO";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	};
}
