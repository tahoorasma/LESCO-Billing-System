#pragma once

namespace ISEIncrement3 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for NewBill
	/// </summary>
	public ref class NewBill : public System::Windows::Forms::Form
	{
	public:
		NewBill(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~NewBill()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::PictureBox^  pictureBox1;
	private: System::Windows::Forms::TextBox^  textBoxPW;
	private: System::Windows::Forms::TextBox^  textBoxmonth;
	private: System::Windows::Forms::TextBox^  textBoxRegUnit;
	private: System::Windows::Forms::TextBox^  textBoxPeakHour;
	private: System::Windows::Forms::TextBox^  textBoxDdate;
	protected: 





	private: System::Windows::Forms::TextBox^  textBoxID;

	private: System::Windows::Forms::Button^  Enterbutton;
	private: System::Windows::Forms::Label^  Peak;
	private: System::Windows::Forms::Label^  Ddate;


	private: System::Windows::Forms::Label^  PW;
	private: System::Windows::Forms::Label^  BillingMonth;
	private: System::Windows::Forms::Label^  RegReading;



	private: System::Windows::Forms::Label^  ID;

	private: System::Windows::Forms::Label^  customer;
	private: System::Windows::Forms::Label^  Dmonth;
	private: System::Windows::Forms::Label^  Dyear;
	private: System::Windows::Forms::TextBox^  textBoxDmonthg;
	private: System::Windows::Forms::TextBox^  textBoxDyear;
	private: System::Windows::Forms::Label^  label1;


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(NewBill::typeid));
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->textBoxPW = (gcnew System::Windows::Forms::TextBox());
			this->textBoxmonth = (gcnew System::Windows::Forms::TextBox());
			this->textBoxRegUnit = (gcnew System::Windows::Forms::TextBox());
			this->textBoxPeakHour = (gcnew System::Windows::Forms::TextBox());
			this->textBoxDdate = (gcnew System::Windows::Forms::TextBox());
			this->textBoxID = (gcnew System::Windows::Forms::TextBox());
			this->Enterbutton = (gcnew System::Windows::Forms::Button());
			this->Peak = (gcnew System::Windows::Forms::Label());
			this->Ddate = (gcnew System::Windows::Forms::Label());
			this->PW = (gcnew System::Windows::Forms::Label());
			this->BillingMonth = (gcnew System::Windows::Forms::Label());
			this->RegReading = (gcnew System::Windows::Forms::Label());
			this->ID = (gcnew System::Windows::Forms::Label());
			this->customer = (gcnew System::Windows::Forms::Label());
			this->Dmonth = (gcnew System::Windows::Forms::Label());
			this->Dyear = (gcnew System::Windows::Forms::Label());
			this->textBoxDmonthg = (gcnew System::Windows::Forms::TextBox());
			this->textBoxDyear = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackColor = System::Drawing::Color::Transparent;
			this->pictureBox1->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox1.BackgroundImage")));
			this->pictureBox1->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->pictureBox1->Location = System::Drawing::Point(2, 0);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(32, 29);
			this->pictureBox1->TabIndex = 58;
			this->pictureBox1->TabStop = false;
			// 
			// textBoxPW
			// 
			this->textBoxPW->BackColor = System::Drawing::SystemColors::ButtonFace;
			this->textBoxPW->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->textBoxPW->Location = System::Drawing::Point(263, 93);
			this->textBoxPW->Name = L"textBoxPW";
			this->textBoxPW->Size = System::Drawing::Size(136, 20);
			this->textBoxPW->TabIndex = 57;
			// 
			// textBoxmonth
			// 
			this->textBoxmonth->BackColor = System::Drawing::SystemColors::ButtonFace;
			this->textBoxmonth->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->textBoxmonth->Location = System::Drawing::Point(263, 115);
			this->textBoxmonth->Name = L"textBoxmonth";
			this->textBoxmonth->Size = System::Drawing::Size(136, 20);
			this->textBoxmonth->TabIndex = 56;
			// 
			// textBoxRegUnit
			// 
			this->textBoxRegUnit->BackColor = System::Drawing::SystemColors::ButtonFace;
			this->textBoxRegUnit->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->textBoxRegUnit->Location = System::Drawing::Point(263, 139);
			this->textBoxRegUnit->Name = L"textBoxRegUnit";
			this->textBoxRegUnit->Size = System::Drawing::Size(136, 20);
			this->textBoxRegUnit->TabIndex = 55;
			// 
			// textBoxPeakHour
			// 
			this->textBoxPeakHour->BackColor = System::Drawing::SystemColors::ButtonFace;
			this->textBoxPeakHour->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->textBoxPeakHour->Location = System::Drawing::Point(263, 164);
			this->textBoxPeakHour->Name = L"textBoxPeakHour";
			this->textBoxPeakHour->Size = System::Drawing::Size(136, 20);
			this->textBoxPeakHour->TabIndex = 54;
			// 
			// textBoxDdate
			// 
			this->textBoxDdate->BackColor = System::Drawing::SystemColors::ButtonFace;
			this->textBoxDdate->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->textBoxDdate->Location = System::Drawing::Point(116, 228);
			this->textBoxDdate->Name = L"textBoxDdate";
			this->textBoxDdate->Size = System::Drawing::Size(136, 20);
			this->textBoxDdate->TabIndex = 53;
			// 
			// textBoxID
			// 
			this->textBoxID->BackColor = System::Drawing::SystemColors::ButtonFace;
			this->textBoxID->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->textBoxID->Location = System::Drawing::Point(263, 70);
			this->textBoxID->Name = L"textBoxID";
			this->textBoxID->Size = System::Drawing::Size(136, 20);
			this->textBoxID->TabIndex = 52;
			// 
			// Enterbutton
			// 
			this->Enterbutton->BackColor = System::Drawing::Color::Transparent;
			this->Enterbutton->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->Enterbutton->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Enterbutton->Location = System::Drawing::Point(213, 304);
			this->Enterbutton->Name = L"Enterbutton";
			this->Enterbutton->Size = System::Drawing::Size(82, 29);
			this->Enterbutton->TabIndex = 51;
			this->Enterbutton->Text = L"Enter";
			this->Enterbutton->UseVisualStyleBackColor = false;
			// 
			// Peak
			// 
			this->Peak->AutoSize = true;
			this->Peak->BackColor = System::Drawing::Color::Transparent;
			this->Peak->Font = (gcnew System::Drawing::Font(L"Georgia", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Peak->Location = System::Drawing::Point(34, 162);
			this->Peak->Name = L"Peak";
			this->Peak->Size = System::Drawing::Size(194, 23);
			this->Peak->TabIndex = 50;
			this->Peak->Text = L"Peak Hours Reading: ";
			// 
			// Ddate
			// 
			this->Ddate->AutoSize = true;
			this->Ddate->BackColor = System::Drawing::Color::Transparent;
			this->Ddate->Font = (gcnew System::Drawing::Font(L"Georgia", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Ddate->Location = System::Drawing::Point(34, 225);
			this->Ddate->Name = L"Ddate";
			this->Ddate->Size = System::Drawing::Size(56, 23);
			this->Ddate->TabIndex = 49;
			this->Ddate->Text = L"Date:";
			// 
			// PW
			// 
			this->PW->AutoSize = true;
			this->PW->BackColor = System::Drawing::Color::Transparent;
			this->PW->Font = (gcnew System::Drawing::Font(L"Georgia", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->PW->Location = System::Drawing::Point(34, 93);
			this->PW->Name = L"PW";
			this->PW->Size = System::Drawing::Size(102, 23);
			this->PW->TabIndex = 48;
			this->PW->Text = L"Password: ";
			this->PW->Click += gcnew System::EventHandler(this, &NewBill::name_Click);
			// 
			// BillingMonth
			// 
			this->BillingMonth->AutoSize = true;
			this->BillingMonth->BackColor = System::Drawing::Color::Transparent;
			this->BillingMonth->Font = (gcnew System::Drawing::Font(L"Georgia", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->BillingMonth->Location = System::Drawing::Point(34, 116);
			this->BillingMonth->Name = L"BillingMonth";
			this->BillingMonth->Size = System::Drawing::Size(138, 23);
			this->BillingMonth->TabIndex = 47;
			this->BillingMonth->Text = L"Billing Month: ";
			// 
			// RegReading
			// 
			this->RegReading->AutoSize = true;
			this->RegReading->BackColor = System::Drawing::Color::Transparent;
			this->RegReading->Font = (gcnew System::Drawing::Font(L"Georgia", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->RegReading->Location = System::Drawing::Point(34, 139);
			this->RegReading->Name = L"RegReading";
			this->RegReading->Size = System::Drawing::Size(218, 23);
			this->RegReading->TabIndex = 46;
			this->RegReading->Text = L"Regular Meter Reading: ";
			// 
			// ID
			// 
			this->ID->AutoSize = true;
			this->ID->BackColor = System::Drawing::Color::Transparent;
			this->ID->Font = (gcnew System::Drawing::Font(L"Georgia", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->ID->Location = System::Drawing::Point(34, 70);
			this->ID->Name = L"ID";
			this->ID->Size = System::Drawing::Size(86, 23);
			this->ID->TabIndex = 45;
			this->ID->Text = L"User ID: ";
			// 
			// customer
			// 
			this->customer->AutoSize = true;
			this->customer->BackColor = System::Drawing::Color::Transparent;
			this->customer->Font = (gcnew System::Drawing::Font(L"Georgia", 15.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->customer->Location = System::Drawing::Point(33, 32);
			this->customer->Name = L"customer";
			this->customer->Size = System::Drawing::Size(456, 25);
			this->customer->TabIndex = 44;
			this->customer->Text = L"Enter details for a new customer to add the bill: ";
			// 
			// Dmonth
			// 
			this->Dmonth->AutoSize = true;
			this->Dmonth->BackColor = System::Drawing::Color::Transparent;
			this->Dmonth->Font = (gcnew System::Drawing::Font(L"Georgia", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Dmonth->Location = System::Drawing::Point(34, 248);
			this->Dmonth->Name = L"Dmonth";
			this->Dmonth->Size = System::Drawing::Size(73, 23);
			this->Dmonth->TabIndex = 59;
			this->Dmonth->Text = L"Month:";
			// 
			// Dyear
			// 
			this->Dyear->AutoSize = true;
			this->Dyear->BackColor = System::Drawing::Color::Transparent;
			this->Dyear->Font = (gcnew System::Drawing::Font(L"Georgia", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Dyear->Location = System::Drawing::Point(34, 274);
			this->Dyear->Name = L"Dyear";
			this->Dyear->Size = System::Drawing::Size(55, 23);
			this->Dyear->TabIndex = 60;
			this->Dyear->Text = L"Year:";
			// 
			// textBoxDmonthg
			// 
			this->textBoxDmonthg->BackColor = System::Drawing::SystemColors::ButtonFace;
			this->textBoxDmonthg->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->textBoxDmonthg->Location = System::Drawing::Point(116, 251);
			this->textBoxDmonthg->Name = L"textBoxDmonthg";
			this->textBoxDmonthg->Size = System::Drawing::Size(136, 20);
			this->textBoxDmonthg->TabIndex = 61;
			// 
			// textBoxDyear
			// 
			this->textBoxDyear->BackColor = System::Drawing::SystemColors::ButtonFace;
			this->textBoxDyear->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->textBoxDyear->Location = System::Drawing::Point(116, 277);
			this->textBoxDyear->Name = L"textBoxDyear";
			this->textBoxDyear->Size = System::Drawing::Size(136, 20);
			this->textBoxDyear->TabIndex = 62;
			this->textBoxDyear->TextChanged += gcnew System::EventHandler(this, &NewBill::textBox2_TextChanged);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->BackColor = System::Drawing::Color::Transparent;
			this->label1->Font = (gcnew System::Drawing::Font(L"Georgia", 15.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(33, 200);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(299, 25);
			this->label1->TabIndex = 63;
			this->label1->Text = L"Enter Due Date (dd/mm/yyyy)";
			// 
			// NewBill
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"$this.BackgroundImage")));
			this->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->ClientSize = System::Drawing::Size(635, 366);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->textBoxDyear);
			this->Controls->Add(this->textBoxDmonthg);
			this->Controls->Add(this->Dyear);
			this->Controls->Add(this->Dmonth);
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->textBoxPW);
			this->Controls->Add(this->textBoxmonth);
			this->Controls->Add(this->textBoxRegUnit);
			this->Controls->Add(this->textBoxPeakHour);
			this->Controls->Add(this->textBoxDdate);
			this->Controls->Add(this->textBoxID);
			this->Controls->Add(this->Enterbutton);
			this->Controls->Add(this->Peak);
			this->Controls->Add(this->Ddate);
			this->Controls->Add(this->PW);
			this->Controls->Add(this->BillingMonth);
			this->Controls->Add(this->RegReading);
			this->Controls->Add(this->ID);
			this->Controls->Add(this->customer);
			this->Name = L"NewBill";
			this->Text = L"LESCO";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void name_Click(System::Object^  sender, System::EventArgs^  e) {
			 }
private: System::Void textBox2_TextChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
};
}
