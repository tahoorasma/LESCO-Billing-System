#pragma once

namespace ISEIncrement3 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for BillingInfo
	/// </summary>
	public ref class BillingInfo : public System::Windows::Forms::Form
	{
	public:
		BillingInfo(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~BillingInfo()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::PictureBox^  pictureBox1;
	private: System::Windows::Forms::Button^  Searchbutton;
	private: System::Windows::Forms::Button^  PayBill;
	private: System::Windows::Forms::Button^  PaidAnfUnpaidbutton;
	private: System::Windows::Forms::Button^  AddaNewBillButton;
	private: System::Windows::Forms::Button^  Displaybutton;
	private: System::Windows::Forms::Label^  EmployeesPortal;
	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(BillingInfo::typeid));
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->Searchbutton = (gcnew System::Windows::Forms::Button());
			this->PayBill = (gcnew System::Windows::Forms::Button());
			this->PaidAnfUnpaidbutton = (gcnew System::Windows::Forms::Button());
			this->AddaNewBillButton = (gcnew System::Windows::Forms::Button());
			this->Displaybutton = (gcnew System::Windows::Forms::Button());
			this->EmployeesPortal = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox1.BackgroundImage")));
			this->pictureBox1->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->pictureBox1->Location = System::Drawing::Point(0, 1);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(37, 31);
			this->pictureBox1->TabIndex = 5;
			this->pictureBox1->TabStop = false;
			// 
			// Searchbutton
			// 
			this->Searchbutton->BackColor = System::Drawing::Color::Teal;
			this->Searchbutton->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->Searchbutton->Font = (gcnew System::Drawing::Font(L"Georgia", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Searchbutton->Location = System::Drawing::Point(186, 148);
			this->Searchbutton->Name = L"Searchbutton";
			this->Searchbutton->Size = System::Drawing::Size(205, 34);
			this->Searchbutton->TabIndex = 27;
			this->Searchbutton->Text = L"Search";
			this->Searchbutton->UseVisualStyleBackColor = false;
			// 
			// PayBill
			// 
			this->PayBill->BackColor = System::Drawing::Color::Teal;
			this->PayBill->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->PayBill->Font = (gcnew System::Drawing::Font(L"Georgia", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->PayBill->Location = System::Drawing::Point(186, 188);
			this->PayBill->Name = L"PayBill";
			this->PayBill->Size = System::Drawing::Size(205, 38);
			this->PayBill->TabIndex = 26;
			this->PayBill->Text = L"Pay Bill";
			this->PayBill->UseVisualStyleBackColor = false;
			// 
			// PaidAnfUnpaidbutton
			// 
			this->PaidAnfUnpaidbutton->BackColor = System::Drawing::Color::Teal;
			this->PaidAnfUnpaidbutton->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->PaidAnfUnpaidbutton->Font = (gcnew System::Drawing::Font(L"Georgia", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->PaidAnfUnpaidbutton->Location = System::Drawing::Point(186, 232);
			this->PaidAnfUnpaidbutton->Name = L"PaidAnfUnpaidbutton";
			this->PaidAnfUnpaidbutton->Size = System::Drawing::Size(205, 34);
			this->PaidAnfUnpaidbutton->TabIndex = 25;
			this->PaidAnfUnpaidbutton->Text = L"View paid and unpaid bills";
			this->PaidAnfUnpaidbutton->UseVisualStyleBackColor = false;
			// 
			// AddaNewBillButton
			// 
			this->AddaNewBillButton->BackColor = System::Drawing::Color::Teal;
			this->AddaNewBillButton->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->AddaNewBillButton->Font = (gcnew System::Drawing::Font(L"Georgia", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->AddaNewBillButton->Location = System::Drawing::Point(186, 64);
			this->AddaNewBillButton->Name = L"AddaNewBillButton";
			this->AddaNewBillButton->Size = System::Drawing::Size(205, 34);
			this->AddaNewBillButton->TabIndex = 24;
			this->AddaNewBillButton->Text = L"Add a new Bill";
			this->AddaNewBillButton->UseVisualStyleBackColor = false;
			// 
			// Displaybutton
			// 
			this->Displaybutton->BackColor = System::Drawing::Color::Teal;
			this->Displaybutton->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->Displaybutton->Font = (gcnew System::Drawing::Font(L"Georgia", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Displaybutton->Location = System::Drawing::Point(186, 104);
			this->Displaybutton->Name = L"Displaybutton";
			this->Displaybutton->Size = System::Drawing::Size(205, 38);
			this->Displaybutton->TabIndex = 22;
			this->Displaybutton->Text = L"Display";
			this->Displaybutton->UseVisualStyleBackColor = false;
			// 
			// EmployeesPortal
			// 
			this->EmployeesPortal->AutoSize = true;
			this->EmployeesPortal->BackColor = System::Drawing::Color::Transparent;
			this->EmployeesPortal->Font = (gcnew System::Drawing::Font(L"Georgia", 24, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->EmployeesPortal->Location = System::Drawing::Point(150, 9);
			this->EmployeesPortal->Name = L"EmployeesPortal";
			this->EmployeesPortal->Size = System::Drawing::Size(288, 38);
			this->EmployeesPortal->TabIndex = 21;
			this->EmployeesPortal->Text = L"Billing Information";
			// 
			// BillingInfo
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"$this.BackgroundImage")));
			this->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->ClientSize = System::Drawing::Size(542, 289);
			this->Controls->Add(this->Searchbutton);
			this->Controls->Add(this->PayBill);
			this->Controls->Add(this->PaidAnfUnpaidbutton);
			this->Controls->Add(this->AddaNewBillButton);
			this->Controls->Add(this->Displaybutton);
			this->Controls->Add(this->EmployeesPortal);
			this->Controls->Add(this->pictureBox1);
			this->Name = L"BillingInfo";
			this->Text = L"LESCO ";
			this->Load += gcnew System::EventHandler(this, &BillingInfo::BillingInfo_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void BillingInfo_Load(System::Object^  sender, System::EventArgs^  e) {
			 }
	};
}
