#pragma once

namespace ISEIncrement3 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for UpdateTariff
	/// </summary>
	public ref class UpdateTariff : public System::Windows::Forms::Form
	{
	public:
		UpdateTariff(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~UpdateTariff()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::PictureBox^  pictureBox1;
	protected: 
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::TextBox^  textBoxMtype;
	private: System::Windows::Forms::TextBox^  textBoxCtype;
	private: System::Windows::Forms::Label^  Mtypelabel;
	private: System::Windows::Forms::Label^  CustomerTypelabel;
	private: System::Windows::Forms::Label^  label;
	private: System::Windows::Forms::Label^  labelregUnitPrice;
	private: System::Windows::Forms::Label^  labelPeakHourUnitPrice;
	private: System::Windows::Forms::Label^  labelTaxPercentage;
	private: System::Windows::Forms::Label^  labelFixCharges;
	private: System::Windows::Forms::TextBox^  textBoxChoice;
	private: System::Windows::Forms::Label^  labelvalue;
	private: System::Windows::Forms::TextBox^  textBoxvalue;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(UpdateTariff::typeid));
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->textBoxMtype = (gcnew System::Windows::Forms::TextBox());
			this->textBoxCtype = (gcnew System::Windows::Forms::TextBox());
			this->Mtypelabel = (gcnew System::Windows::Forms::Label());
			this->CustomerTypelabel = (gcnew System::Windows::Forms::Label());
			this->label = (gcnew System::Windows::Forms::Label());
			this->labelregUnitPrice = (gcnew System::Windows::Forms::Label());
			this->labelPeakHourUnitPrice = (gcnew System::Windows::Forms::Label());
			this->labelTaxPercentage = (gcnew System::Windows::Forms::Label());
			this->labelFixCharges = (gcnew System::Windows::Forms::Label());
			this->textBoxChoice = (gcnew System::Windows::Forms::TextBox());
			this->labelvalue = (gcnew System::Windows::Forms::Label());
			this->textBoxvalue = (gcnew System::Windows::Forms::TextBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackColor = System::Drawing::Color::Transparent;
			this->pictureBox1->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox1.BackgroundImage")));
			this->pictureBox1->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->pictureBox1->Location = System::Drawing::Point(-2, -1);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(32, 29);
			this->pictureBox1->TabIndex = 51;
			this->pictureBox1->TabStop = false;
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::Color::Transparent;
			this->button1->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button1->Font = (gcnew System::Drawing::Font(L"Georgia", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->button1->Location = System::Drawing::Point(229, 272);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 32);
			this->button1->TabIndex = 50;
			this->button1->Text = L"Enter";
			this->button1->UseVisualStyleBackColor = false;
			// 
			// textBoxMtype
			// 
			this->textBoxMtype->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBoxMtype->Location = System::Drawing::Point(216, 73);
			this->textBoxMtype->Name = L"textBoxMtype";
			this->textBoxMtype->Size = System::Drawing::Size(164, 29);
			this->textBoxMtype->TabIndex = 49;
			// 
			// textBoxCtype
			// 
			this->textBoxCtype->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBoxCtype->Location = System::Drawing::Point(216, 36);
			this->textBoxCtype->Name = L"textBoxCtype";
			this->textBoxCtype->Size = System::Drawing::Size(164, 29);
			this->textBoxCtype->TabIndex = 48;
			// 
			// Mtypelabel
			// 
			this->Mtypelabel->AutoSize = true;
			this->Mtypelabel->BackColor = System::Drawing::Color::Transparent;
			this->Mtypelabel->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->Mtypelabel->Font = (gcnew System::Drawing::Font(L"Georgia", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Mtypelabel->Location = System::Drawing::Point(35, 73);
			this->Mtypelabel->Name = L"Mtypelabel";
			this->Mtypelabel->Size = System::Drawing::Size(118, 23);
			this->Mtypelabel->TabIndex = 47;
			this->Mtypelabel->Text = L"Meter Type: ";
			// 
			// CustomerTypelabel
			// 
			this->CustomerTypelabel->AutoSize = true;
			this->CustomerTypelabel->BackColor = System::Drawing::Color::Transparent;
			this->CustomerTypelabel->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->CustomerTypelabel->Font = (gcnew System::Drawing::Font(L"Georgia", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->CustomerTypelabel->Location = System::Drawing::Point(36, 40);
			this->CustomerTypelabel->Name = L"CustomerTypelabel";
			this->CustomerTypelabel->Size = System::Drawing::Size(149, 23);
			this->CustomerTypelabel->TabIndex = 46;
			this->CustomerTypelabel->Text = L"Customer Type: ";
			// 
			// label
			// 
			this->label->AutoSize = true;
			this->label->BackColor = System::Drawing::Color::Transparent;
			this->label->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->label->Font = (gcnew System::Drawing::Font(L"Georgia", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label->Location = System::Drawing::Point(28, 197);
			this->label->Name = L"label";
			this->label->Size = System::Drawing::Size(148, 23);
			this->label->TabIndex = 45;
			this->label->Text = L"Choose Update: ";
			// 
			// labelregUnitPrice
			// 
			this->labelregUnitPrice->AutoSize = true;
			this->labelregUnitPrice->BackColor = System::Drawing::Color::Transparent;
			this->labelregUnitPrice->Font = (gcnew System::Drawing::Font(L"Georgia", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->labelregUnitPrice->Location = System::Drawing::Point(31, 116);
			this->labelregUnitPrice->Name = L"labelregUnitPrice";
			this->labelregUnitPrice->Size = System::Drawing::Size(154, 18);
			this->labelregUnitPrice->TabIndex = 52;
			this->labelregUnitPrice->Text = L"1. Regular Unit Price";
			// 
			// labelPeakHourUnitPrice
			// 
			this->labelPeakHourUnitPrice->AutoSize = true;
			this->labelPeakHourUnitPrice->BackColor = System::Drawing::Color::Transparent;
			this->labelPeakHourUnitPrice->Font = (gcnew System::Drawing::Font(L"Georgia", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->labelPeakHourUnitPrice->Location = System::Drawing::Point(31, 134);
			this->labelPeakHourUnitPrice->Name = L"labelPeakHourUnitPrice";
			this->labelPeakHourUnitPrice->Size = System::Drawing::Size(175, 18);
			this->labelPeakHourUnitPrice->TabIndex = 53;
			this->labelPeakHourUnitPrice->Text = L"2. Peak Hour Unit Price";
			// 
			// labelTaxPercentage
			// 
			this->labelTaxPercentage->AutoSize = true;
			this->labelTaxPercentage->BackColor = System::Drawing::Color::Transparent;
			this->labelTaxPercentage->Font = (gcnew System::Drawing::Font(L"Georgia", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->labelTaxPercentage->Location = System::Drawing::Point(30, 152);
			this->labelTaxPercentage->Name = L"labelTaxPercentage";
			this->labelTaxPercentage->Size = System::Drawing::Size(142, 18);
			this->labelTaxPercentage->TabIndex = 54;
			this->labelTaxPercentage->Text = L"3. Tax percentages";
			// 
			// labelFixCharges
			// 
			this->labelFixCharges->AutoSize = true;
			this->labelFixCharges->BackColor = System::Drawing::Color::Transparent;
			this->labelFixCharges->Font = (gcnew System::Drawing::Font(L"Georgia", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->labelFixCharges->Location = System::Drawing::Point(31, 170);
			this->labelFixCharges->Name = L"labelFixCharges";
			this->labelFixCharges->Size = System::Drawing::Size(126, 18);
			this->labelFixCharges->TabIndex = 55;
			this->labelFixCharges->Text = L"4. Fixed Charges";
			// 
			// textBoxChoice
			// 
			this->textBoxChoice->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBoxChoice->Location = System::Drawing::Point(216, 194);
			this->textBoxChoice->Name = L"textBoxChoice";
			this->textBoxChoice->Size = System::Drawing::Size(164, 26);
			this->textBoxChoice->TabIndex = 56;
			// 
			// labelvalue
			// 
			this->labelvalue->AutoSize = true;
			this->labelvalue->BackColor = System::Drawing::Color::Transparent;
			this->labelvalue->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->labelvalue->Font = (gcnew System::Drawing::Font(L"Georgia", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->labelvalue->Location = System::Drawing::Point(30, 220);
			this->labelvalue->Name = L"labelvalue";
			this->labelvalue->Size = System::Drawing::Size(151, 23);
			this->labelvalue->TabIndex = 57;
			this->labelvalue->Text = L"Enter new value:";
			// 
			// textBoxvalue
			// 
			this->textBoxvalue->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBoxvalue->Location = System::Drawing::Point(216, 220);
			this->textBoxvalue->Name = L"textBoxvalue";
			this->textBoxvalue->Size = System::Drawing::Size(164, 26);
			this->textBoxvalue->TabIndex = 58;
			// 
			// UpdateTariff
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"$this.BackgroundImage")));
			this->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->ClientSize = System::Drawing::Size(580, 316);
			this->Controls->Add(this->textBoxvalue);
			this->Controls->Add(this->labelvalue);
			this->Controls->Add(this->textBoxChoice);
			this->Controls->Add(this->labelFixCharges);
			this->Controls->Add(this->labelTaxPercentage);
			this->Controls->Add(this->labelPeakHourUnitPrice);
			this->Controls->Add(this->labelregUnitPrice);
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->textBoxMtype);
			this->Controls->Add(this->textBoxCtype);
			this->Controls->Add(this->Mtypelabel);
			this->Controls->Add(this->CustomerTypelabel);
			this->Controls->Add(this->label);
			this->Name = L"UpdateTariff";
			this->Text = L"UpdateTariff";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	};
}
