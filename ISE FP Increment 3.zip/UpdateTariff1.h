#pragma once

namespace ISEIncrement3 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for UpdateTariff
	/// </summary>
	public ref class UpdateTariff : public System::Windows::Forms::Form
	{
	public:
		UpdateTariff(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~UpdateTariff()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::PictureBox^  pictureBox1;
	private: System::Windows::Forms::TextBox^  textBoxPW;
	private: System::Windows::Forms::TextBox^  textBoxID;
	private: System::Windows::Forms::Label^  PWlabel;
	private: System::Windows::Forms::Label^  IDlabel;
	private: System::Windows::Forms::Label^  customer;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Windows::Forms::Label^  label5;
	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(UpdateTariff::typeid));
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->textBoxPW = (gcnew System::Windows::Forms::TextBox());
			this->textBoxID = (gcnew System::Windows::Forms::TextBox());
			this->PWlabel = (gcnew System::Windows::Forms::Label());
			this->IDlabel = (gcnew System::Windows::Forms::Label());
			this->customer = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->label5 = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox1.BackgroundImage")));
			this->pictureBox1->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->pictureBox1->Location = System::Drawing::Point(0, -1);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(37, 31);
			this->pictureBox1->TabIndex = 10;
			this->pictureBox1->TabStop = false;
			// 
			// textBoxPW
			// 
			this->textBoxPW->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBoxPW->Location = System::Drawing::Point(208, 57);
			this->textBoxPW->Name = L"textBoxPW";
			this->textBoxPW->PasswordChar = '*';
			this->textBoxPW->Size = System::Drawing::Size(164, 31);
			this->textBoxPW->TabIndex = 15;
			// 
			// textBoxID
			// 
			this->textBoxID->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBoxID->Location = System::Drawing::Point(208, 20);
			this->textBoxID->Name = L"textBoxID";
			this->textBoxID->Size = System::Drawing::Size(164, 31);
			this->textBoxID->TabIndex = 14;
			// 
			// PWlabel
			// 
			this->PWlabel->AutoSize = true;
			this->PWlabel->BackColor = System::Drawing::Color::Transparent;
			this->PWlabel->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->PWlabel->Font = (gcnew System::Drawing::Font(L"Georgia", 15.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->PWlabel->Location = System::Drawing::Point(43, 63);
			this->PWlabel->Name = L"PWlabel";
			this->PWlabel->Size = System::Drawing::Size(124, 25);
			this->PWlabel->TabIndex = 13;
			this->PWlabel->Text = L"Meter Type:";
			// 
			// IDlabel
			// 
			this->IDlabel->AutoSize = true;
			this->IDlabel->BackColor = System::Drawing::Color::Transparent;
			this->IDlabel->CausesValidation = false;
			this->IDlabel->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->IDlabel->Font = (gcnew System::Drawing::Font(L"Georgia", 15.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->IDlabel->Location = System::Drawing::Point(43, 27);
			this->IDlabel->Name = L"IDlabel";
			this->IDlabel->Size = System::Drawing::Size(159, 25);
			this->IDlabel->TabIndex = 12;
			this->IDlabel->Text = L"Customer Type:";
			// 
			// customer
			// 
			this->customer->AutoSize = true;
			this->customer->BackColor = System::Drawing::Color::Transparent;
			this->customer->Font = (gcnew System::Drawing::Font(L"Georgia", 15.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->customer->Location = System::Drawing::Point(43, 103);
			this->customer->Name = L"customer";
			this->customer->Size = System::Drawing::Size(200, 25);
			this->customer->TabIndex = 45;
			this->customer->Text = L"1. Regular unit price";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->BackColor = System::Drawing::Color::Transparent;
			this->label1->Font = (gcnew System::Drawing::Font(L"Georgia", 15.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(43, 128);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(228, 25);
			this->label1->TabIndex = 46;
			this->label1->Text = L"2. Peak Hour unit price";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->BackColor = System::Drawing::Color::Transparent;
			this->label2->Font = (gcnew System::Drawing::Font(L"Georgia", 15.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(52, 161);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(0, 25);
			this->label2->TabIndex = 47;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->BackColor = System::Drawing::Color::Transparent;
			this->label3->Font = (gcnew System::Drawing::Font(L"Georgia", 15.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(43, 153);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(177, 25);
			this->label3->TabIndex = 48;
			this->label3->Text = L"3. Tax percentage";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->BackColor = System::Drawing::Color::Transparent;
			this->label4->Font = (gcnew System::Drawing::Font(L"Georgia", 15.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(43, 178);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(167, 25);
			this->label4->TabIndex = 49;
			this->label4->Text = L"4. Fixed Charges";
			this->label4->Click += gcnew System::EventHandler(this, &UpdateTariff::label4_Click);
			// 
			// textBox1
			// 
			this->textBox1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox1->Location = System::Drawing::Point(208, 209);
			this->textBox1->Name = L"textBox1";
			this->textBox1->PasswordChar = '*';
			this->textBox1->Size = System::Drawing::Size(164, 31);
			this->textBox1->TabIndex = 51;
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->BackColor = System::Drawing::Color::Transparent;
			this->label5->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->label5->Font = (gcnew System::Drawing::Font(L"Georgia", 15.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label5->Location = System::Drawing::Point(43, 215);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(143, 25);
			this->label5->TabIndex = 50;
			this->label5->Text = L"Enter Choice: ";
			// 
			// UpdateTariff
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"$this.BackgroundImage")));
			this->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->ClientSize = System::Drawing::Size(615, 299);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->customer);
			this->Controls->Add(this->textBoxPW);
			this->Controls->Add(this->textBoxID);
			this->Controls->Add(this->PWlabel);
			this->Controls->Add(this->IDlabel);
			this->Controls->Add(this->pictureBox1);
			this->Name = L"UpdateTariff";
			this->Text = L"UpdateTariff";
			this->Load += gcnew System::EventHandler(this, &UpdateTariff::UpdateTariff_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void UpdateTariff_Load(System::Object^  sender, System::EventArgs^  e) {
			 }
private: System::Void label4_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
};
}
