#pragma once
#include<iostream>
#include<fstream>
#include<stdlib.h>
#include<string>
#include<cstring>
#include<io.h>
#include<filesystem>
#include<stdio.h>

#include"NewCustomer.h"
#include"EmployeePage.h"
#include"Display.h"

#pragma warning(push)
#pragma warning(disable: 4101)

namespace ISEIncrement3 {

	using namespace std;
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::IO;

	/// <summary>
	/// Summary for EmployeePage
	/// </summary>
	public ref class EmployeePage : public System::Windows::Forms::Form
	{
	public:
		EmployeePage(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~EmployeePage()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  Searchbutton;
	protected: 
	private: System::Windows::Forms::Button^  CNICExpiryDatesbutton;
	private: System::Windows::Forms::Button^  BillingInfobutton;
	private: System::Windows::Forms::Button^  AddaNewCustomerButton;

	private: System::Windows::Forms::Button^  UpdateATariffbutton;
	private: System::Windows::Forms::Button^  Displaybutton;


	private: System::Windows::Forms::Label^  EmployeesPortal;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(EmployeePage::typeid));
			this->Searchbutton = (gcnew System::Windows::Forms::Button());
			this->CNICExpiryDatesbutton = (gcnew System::Windows::Forms::Button());
			this->BillingInfobutton = (gcnew System::Windows::Forms::Button());
			this->AddaNewCustomerButton = (gcnew System::Windows::Forms::Button());
			this->UpdateATariffbutton = (gcnew System::Windows::Forms::Button());
			this->Displaybutton = (gcnew System::Windows::Forms::Button());
			this->EmployeesPortal = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// Searchbutton
			// 
			this->Searchbutton->BackColor = System::Drawing::Color::Teal;
			this->Searchbutton->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->Searchbutton->Font = (gcnew System::Drawing::Font(L"Georgia", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Searchbutton->Location = System::Drawing::Point(72, 200);
			this->Searchbutton->Name = L"Searchbutton";
			this->Searchbutton->Size = System::Drawing::Size(205, 34);
			this->Searchbutton->TabIndex = 20;
			this->Searchbutton->Text = L"Search";
			this->Searchbutton->UseVisualStyleBackColor = false;
			// 
			// CNICExpiryDatesbutton
			// 
			this->CNICExpiryDatesbutton->BackColor = System::Drawing::Color::Teal;
			this->CNICExpiryDatesbutton->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->CNICExpiryDatesbutton->Font = (gcnew System::Drawing::Font(L"Georgia", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->CNICExpiryDatesbutton->Location = System::Drawing::Point(345, 94);
			this->CNICExpiryDatesbutton->Name = L"CNICExpiryDatesbutton";
			this->CNICExpiryDatesbutton->Size = System::Drawing::Size(205, 38);
			this->CNICExpiryDatesbutton->TabIndex = 19;
			this->CNICExpiryDatesbutton->Text = L"CNIC Expiry Dates";
			this->CNICExpiryDatesbutton->UseVisualStyleBackColor = false;
			// 
			// BillingInfobutton
			// 
			this->BillingInfobutton->BackColor = System::Drawing::Color::Teal;
			this->BillingInfobutton->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->BillingInfobutton->Font = (gcnew System::Drawing::Font(L"Georgia", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->BillingInfobutton->Location = System::Drawing::Point(345, 148);
			this->BillingInfobutton->Name = L"BillingInfobutton";
			this->BillingInfobutton->Size = System::Drawing::Size(205, 34);
			this->BillingInfobutton->TabIndex = 18;
			this->BillingInfobutton->Text = L"Billing Info";
			this->BillingInfobutton->UseVisualStyleBackColor = false;
			// 
			// AddaNewCustomerButton
			// 
			this->AddaNewCustomerButton->BackColor = System::Drawing::Color::Teal;
			this->AddaNewCustomerButton->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->AddaNewCustomerButton->Font = (gcnew System::Drawing::Font(L"Georgia", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->AddaNewCustomerButton->Location = System::Drawing::Point(72, 94);
			this->AddaNewCustomerButton->Name = L"AddaNewCustomerButton";
			this->AddaNewCustomerButton->Size = System::Drawing::Size(205, 34);
			this->AddaNewCustomerButton->TabIndex = 17;
			this->AddaNewCustomerButton->Text = L"Add a new Customer";
			this->AddaNewCustomerButton->UseVisualStyleBackColor = false;
			this->AddaNewCustomerButton->Click += gcnew System::EventHandler(this, &EmployeePage::AddaNewCustomerButton_Click);
			// 
			// UpdateATariffbutton
			// 
			this->UpdateATariffbutton->BackColor = System::Drawing::Color::Teal;
			this->UpdateATariffbutton->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->UpdateATariffbutton->Font = (gcnew System::Drawing::Font(L"Georgia", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->UpdateATariffbutton->Location = System::Drawing::Point(345, 200);
			this->UpdateATariffbutton->Name = L"UpdateATariffbutton";
			this->UpdateATariffbutton->Size = System::Drawing::Size(205, 34);
			this->UpdateATariffbutton->TabIndex = 16;
			this->UpdateATariffbutton->Text = L"Update a Tariff";
			this->UpdateATariffbutton->UseVisualStyleBackColor = false;
			// 
			// Displaybutton
			// 
			this->Displaybutton->BackColor = System::Drawing::Color::Teal;
			this->Displaybutton->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->Displaybutton->Font = (gcnew System::Drawing::Font(L"Georgia", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Displaybutton->Location = System::Drawing::Point(72, 144);
			this->Displaybutton->Name = L"Displaybutton";
			this->Displaybutton->Size = System::Drawing::Size(205, 38);
			this->Displaybutton->TabIndex = 15;
			this->Displaybutton->Text = L"Display";
			this->Displaybutton->UseVisualStyleBackColor = false;
			this->Displaybutton->Click += gcnew System::EventHandler(this, &EmployeePage::Displaybutton_Click_1);
			// 
			// EmployeesPortal
			// 
			this->EmployeesPortal->AutoSize = true;
			this->EmployeesPortal->BackColor = System::Drawing::Color::Transparent;
			this->EmployeesPortal->Font = (gcnew System::Drawing::Font(L"Georgia", 24, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->EmployeesPortal->Location = System::Drawing::Point(138, 32);
			this->EmployeesPortal->Name = L"EmployeesPortal";
			this->EmployeesPortal->Size = System::Drawing::Size(345, 38);
			this->EmployeesPortal->TabIndex = 14;
			this->EmployeesPortal->Text = L"EMPLOYEES PORTAL";
			// 
			// EmployeePage
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"$this.BackgroundImage")));
			this->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->ClientSize = System::Drawing::Size(631, 319);
			this->Controls->Add(this->Searchbutton);
			this->Controls->Add(this->CNICExpiryDatesbutton);
			this->Controls->Add(this->BillingInfobutton);
			this->Controls->Add(this->AddaNewCustomerButton);
			this->Controls->Add(this->UpdateATariffbutton);
			this->Controls->Add(this->Displaybutton);
			this->Controls->Add(this->EmployeesPortal);
			this->Name = L"EmployeePage";
			this->Text = L"Employees Portal";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void AddaNewCustomerButton_Click(System::Object^  sender, System::EventArgs^  e) {
				/*NewCustomer obj;
				this->Hide();
				obj.ShowDialog();*/
			 }
private: System::Void Displaybutton_Click_1(System::Object^  sender, System::EventArgs^  e) {
				/*Display obj;
				this->Hide();
				obj.ShowDialog();*/
	StreamReader^ fin=File::OpenText("customersInfosample.txt"); //reading and displaying the recently added info from sample file
	String^ displayID;
	String^ displayCnic;
	String^ displayName;
	String^ displayAddress;
	String^ displayPhone;
	String^ displayCustType;
	String^ displayMeterType;
	//fin->displayID>>displayCnic>>displayName>>displayAddress>>displayPhone>>displayCustType>>displayMeterType;
	/*cout<<"Name: "<<displayName<<endl;
	cout<<"Cnic: "<<displayCnic<<endl;
	cout<<"Address: "<<displayAddress<<endl;
	cout<<"Phone No.: "<<displayPhone<<endl;
	cout<<"Customer Type: "<<displayCustType<<endl;
	cout<<"Meter Type: "<<displayMeterType<<endl;
	fin::Close();*/
			 MessageBox::Show("Name: "+displayName+"\nCnic: "+displayCnic+"\nAddress: "+displayAddress+"\nPhone No.: "+displayPhone+"\nCustomer Type: "+displayCustType+"\nMeter Type: "+displayMeterType);

		 }
};
}
