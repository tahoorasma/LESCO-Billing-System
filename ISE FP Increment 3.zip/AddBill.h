#pragma once

namespace ISEIncrement3 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for AddBill
	/// </summary>
	public ref class AddBill : public System::Windows::Forms::Form
	{
	public:
		AddBill(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~AddBill()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::PictureBox^  pictureBox1;
	protected: 
	private: System::Windows::Forms::TextBox^  textBoxPW;
	private: System::Windows::Forms::TextBox^  textBoxmoth;
	private: System::Windows::Forms::TextBox^  textBoxPhoneNo;
	private: System::Windows::Forms::TextBox^  textBoxCtype;
	private: System::Windows::Forms::TextBox^  textBoxDdate;

	private: System::Windows::Forms::TextBox^  textBoxID;
	private: System::Windows::Forms::Button^  Enterbutton;
	private: System::Windows::Forms::Label^  due;
	private: System::Windows::Forms::Label^  PW;
	private: System::Windows::Forms::Label^  month;
	private: System::Windows::Forms::Label^  regMeter;
	private: System::Windows::Forms::Label^  ID;
	private: System::Windows::Forms::Label^  customer;
	private: System::Windows::Forms::Label^  DueDatelabel;
	private: System::Windows::Forms::Label^  labelDueMonth;
	private: System::Windows::Forms::Label^  labelDyear;
	private: System::Windows::Forms::TextBox^  textBoxDmonth;
	private: System::Windows::Forms::TextBox^  textBoxDyear;




	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(AddBill::typeid));
			System::Windows::Forms::Label^  PeakHours;
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->textBoxPW = (gcnew System::Windows::Forms::TextBox());
			this->textBoxmoth = (gcnew System::Windows::Forms::TextBox());
			this->textBoxPhoneNo = (gcnew System::Windows::Forms::TextBox());
			this->textBoxCtype = (gcnew System::Windows::Forms::TextBox());
			this->textBoxDdate = (gcnew System::Windows::Forms::TextBox());
			this->textBoxID = (gcnew System::Windows::Forms::TextBox());
			this->Enterbutton = (gcnew System::Windows::Forms::Button());
			this->due = (gcnew System::Windows::Forms::Label());
			this->PW = (gcnew System::Windows::Forms::Label());
			this->month = (gcnew System::Windows::Forms::Label());
			this->regMeter = (gcnew System::Windows::Forms::Label());
			this->ID = (gcnew System::Windows::Forms::Label());
			this->customer = (gcnew System::Windows::Forms::Label());
			this->DueDatelabel = (gcnew System::Windows::Forms::Label());
			this->labelDueMonth = (gcnew System::Windows::Forms::Label());
			this->labelDyear = (gcnew System::Windows::Forms::Label());
			this->textBoxDmonth = (gcnew System::Windows::Forms::TextBox());
			this->textBoxDyear = (gcnew System::Windows::Forms::TextBox());
			PeakHours = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackColor = System::Drawing::Color::Transparent;
			this->pictureBox1->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox1.BackgroundImage")));
			this->pictureBox1->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->pictureBox1->Location = System::Drawing::Point(0, 0);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(32, 29);
			this->pictureBox1->TabIndex = 58;
			this->pictureBox1->TabStop = false;
			// 
			// textBoxPW
			// 
			this->textBoxPW->BackColor = System::Drawing::SystemColors::ButtonFace;
			this->textBoxPW->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->textBoxPW->Location = System::Drawing::Point(301, 93);
			this->textBoxPW->Name = L"textBoxPW";
			this->textBoxPW->Size = System::Drawing::Size(136, 20);
			this->textBoxPW->TabIndex = 57;
			// 
			// textBoxmoth
			// 
			this->textBoxmoth->BackColor = System::Drawing::SystemColors::ButtonFace;
			this->textBoxmoth->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->textBoxmoth->Location = System::Drawing::Point(301, 116);
			this->textBoxmoth->Name = L"textBoxmoth";
			this->textBoxmoth->Size = System::Drawing::Size(136, 20);
			this->textBoxmoth->TabIndex = 56;
			// 
			// textBoxPhoneNo
			// 
			this->textBoxPhoneNo->BackColor = System::Drawing::SystemColors::ButtonFace;
			this->textBoxPhoneNo->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->textBoxPhoneNo->Location = System::Drawing::Point(301, 139);
			this->textBoxPhoneNo->Name = L"textBoxPhoneNo";
			this->textBoxPhoneNo->Size = System::Drawing::Size(136, 20);
			this->textBoxPhoneNo->TabIndex = 55;
			// 
			// textBoxCtype
			// 
			this->textBoxCtype->BackColor = System::Drawing::SystemColors::ButtonFace;
			this->textBoxCtype->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->textBoxCtype->Location = System::Drawing::Point(301, 162);
			this->textBoxCtype->Name = L"textBoxCtype";
			this->textBoxCtype->Size = System::Drawing::Size(136, 20);
			this->textBoxCtype->TabIndex = 54;
			// 
			// textBoxDdate
			// 
			this->textBoxDdate->BackColor = System::Drawing::SystemColors::ButtonFace;
			this->textBoxDdate->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->textBoxDdate->Location = System::Drawing::Point(133, 220);
			this->textBoxDdate->Name = L"textBoxDdate";
			this->textBoxDdate->Size = System::Drawing::Size(136, 20);
			this->textBoxDdate->TabIndex = 53;
			// 
			// textBoxID
			// 
			this->textBoxID->BackColor = System::Drawing::SystemColors::ButtonFace;
			this->textBoxID->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->textBoxID->Location = System::Drawing::Point(301, 70);
			this->textBoxID->Name = L"textBoxID";
			this->textBoxID->Size = System::Drawing::Size(136, 20);
			this->textBoxID->TabIndex = 52;
			// 
			// Enterbutton
			// 
			this->Enterbutton->BackColor = System::Drawing::Color::Transparent;
			this->Enterbutton->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->Enterbutton->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Enterbutton->Location = System::Drawing::Point(188, 310);
			this->Enterbutton->Name = L"Enterbutton";
			this->Enterbutton->Size = System::Drawing::Size(82, 29);
			this->Enterbutton->TabIndex = 51;
			this->Enterbutton->Text = L"Enter";
			this->Enterbutton->UseVisualStyleBackColor = false;
			// 
			// PeakHours
			// 
			PeakHours->AutoSize = true;
			PeakHours->BackColor = System::Drawing::Color::Transparent;
			PeakHours->Font = (gcnew System::Drawing::Font(L"Georgia", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			PeakHours->Location = System::Drawing::Point(32, 162);
			PeakHours->Name = L"PeakHours";
			PeakHours->Size = System::Drawing::Size(194, 23);
			PeakHours->TabIndex = 50;
			PeakHours->Text = L"Peak Hours Reading: ";
			// 
			// due
			// 
			this->due->AutoSize = true;
			this->due->BackColor = System::Drawing::Color::Transparent;
			this->due->Font = (gcnew System::Drawing::Font(L"Georgia", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->due->Location = System::Drawing::Point(129, 194);
			this->due->Name = L"due";
			this->due->Size = System::Drawing::Size(141, 23);
			this->due->TabIndex = 49;
			this->due->Text = L"Enter due date:";
			this->due->Click += gcnew System::EventHandler(this, &AddBill::due_Click);
			// 
			// PW
			// 
			this->PW->AutoSize = true;
			this->PW->BackColor = System::Drawing::Color::Transparent;
			this->PW->Font = (gcnew System::Drawing::Font(L"Georgia", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->PW->Location = System::Drawing::Point(32, 93);
			this->PW->Name = L"PW";
			this->PW->Size = System::Drawing::Size(102, 23);
			this->PW->TabIndex = 48;
			this->PW->Text = L"Password: ";
			// 
			// month
			// 
			this->month->AutoSize = true;
			this->month->BackColor = System::Drawing::Color::Transparent;
			this->month->Font = (gcnew System::Drawing::Font(L"Georgia", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->month->Location = System::Drawing::Point(32, 116);
			this->month->Name = L"month";
			this->month->Size = System::Drawing::Size(137, 23);
			this->month->TabIndex = 47;
			this->month->Text = L"Billing month: ";
			// 
			// regMeter
			// 
			this->regMeter->AutoSize = true;
			this->regMeter->BackColor = System::Drawing::Color::Transparent;
			this->regMeter->Font = (gcnew System::Drawing::Font(L"Georgia", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->regMeter->Location = System::Drawing::Point(32, 139);
			this->regMeter->Name = L"regMeter";
			this->regMeter->Size = System::Drawing::Size(213, 23);
			this->regMeter->TabIndex = 46;
			this->regMeter->Text = L"Regular Meter Reading:";
			// 
			// ID
			// 
			this->ID->AutoSize = true;
			this->ID->BackColor = System::Drawing::Color::Transparent;
			this->ID->Font = (gcnew System::Drawing::Font(L"Georgia", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->ID->Location = System::Drawing::Point(32, 70);
			this->ID->Name = L"ID";
			this->ID->Size = System::Drawing::Size(86, 23);
			this->ID->TabIndex = 45;
			this->ID->Text = L"User ID: ";
			// 
			// customer
			// 
			this->customer->AutoSize = true;
			this->customer->BackColor = System::Drawing::Color::Transparent;
			this->customer->Font = (gcnew System::Drawing::Font(L"Georgia", 15.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->customer->Location = System::Drawing::Point(31, 32);
			this->customer->Name = L"customer";
			this->customer->Size = System::Drawing::Size(267, 25);
			this->customer->TabIndex = 44;
			this->customer->Text = L"Enter details for a new bill: ";
			// 
			// DueDatelabel
			// 
			this->DueDatelabel->AutoSize = true;
			this->DueDatelabel->BackColor = System::Drawing::Color::Transparent;
			this->DueDatelabel->Font = (gcnew System::Drawing::Font(L"Georgia", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->DueDatelabel->Location = System::Drawing::Point(32, 220);
			this->DueDatelabel->Name = L"DueDatelabel";
			this->DueDatelabel->Size = System::Drawing::Size(56, 23);
			this->DueDatelabel->TabIndex = 59;
			this->DueDatelabel->Text = L"Date:";
			// 
			// labelDueMonth
			// 
			this->labelDueMonth->AutoSize = true;
			this->labelDueMonth->BackColor = System::Drawing::Color::Transparent;
			this->labelDueMonth->Font = (gcnew System::Drawing::Font(L"Georgia", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->labelDueMonth->Location = System::Drawing::Point(32, 243);
			this->labelDueMonth->Name = L"labelDueMonth";
			this->labelDueMonth->Size = System::Drawing::Size(78, 23);
			this->labelDueMonth->TabIndex = 60;
			this->labelDueMonth->Text = L"Month: ";
			// 
			// labelDyear
			// 
			this->labelDyear->AutoSize = true;
			this->labelDyear->BackColor = System::Drawing::Color::Transparent;
			this->labelDyear->Font = (gcnew System::Drawing::Font(L"Georgia", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->labelDyear->Location = System::Drawing::Point(32, 266);
			this->labelDyear->Name = L"labelDyear";
			this->labelDyear->Size = System::Drawing::Size(60, 23);
			this->labelDyear->TabIndex = 61;
			this->labelDyear->Text = L"Year: ";
			// 
			// textBoxDmonth
			// 
			this->textBoxDmonth->BackColor = System::Drawing::SystemColors::ButtonFace;
			this->textBoxDmonth->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->textBoxDmonth->Location = System::Drawing::Point(133, 243);
			this->textBoxDmonth->Name = L"textBoxDmonth";
			this->textBoxDmonth->Size = System::Drawing::Size(136, 20);
			this->textBoxDmonth->TabIndex = 62;
			// 
			// textBoxDyear
			// 
			this->textBoxDyear->BackColor = System::Drawing::SystemColors::ButtonFace;
			this->textBoxDyear->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->textBoxDyear->Location = System::Drawing::Point(133, 266);
			this->textBoxDyear->Name = L"textBoxDyear";
			this->textBoxDyear->Size = System::Drawing::Size(136, 20);
			this->textBoxDyear->TabIndex = 63;
			// 
			// AddBill
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"$this.BackgroundImage")));
			this->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->ClientSize = System::Drawing::Size(587, 351);
			this->Controls->Add(this->textBoxDyear);
			this->Controls->Add(this->textBoxDmonth);
			this->Controls->Add(this->labelDyear);
			this->Controls->Add(this->labelDueMonth);
			this->Controls->Add(this->DueDatelabel);
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->textBoxPW);
			this->Controls->Add(this->textBoxmoth);
			this->Controls->Add(this->textBoxPhoneNo);
			this->Controls->Add(this->textBoxCtype);
			this->Controls->Add(this->textBoxDdate);
			this->Controls->Add(this->textBoxID);
			this->Controls->Add(this->Enterbutton);
			this->Controls->Add(PeakHours);
			this->Controls->Add(this->due);
			this->Controls->Add(this->PW);
			this->Controls->Add(this->month);
			this->Controls->Add(this->regMeter);
			this->Controls->Add(this->ID);
			this->Controls->Add(this->customer);
			this->Name = L"AddBill";
			this->Text = L"AddBill";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void due_Click(System::Object^  sender, System::EventArgs^  e) {
			 }
};
}
